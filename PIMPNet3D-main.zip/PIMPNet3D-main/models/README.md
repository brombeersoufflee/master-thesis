Link to the weight of PIMPNet(s) trained with different folds and model's backbones:

[Google Drive compressed folder](https://drive.google.com/drive/folders/1IdmnXMitZ2qpC_2-324rVBfgKF3Slgl8?usp=share_link)

We trained the model using:

- ResNet3D-18 pre-trained on Kinetics400
- ConvNeXt3D-tiny using pre-trained weights from https://github.com/kiedani/submission_2nd_covid19_competition
